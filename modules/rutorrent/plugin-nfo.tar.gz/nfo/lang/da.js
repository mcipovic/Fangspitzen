﻿
 
theUILang.showNFO = "Show NFO...";
theUILang.nfoNotFound = "Could not find NFO";
theUILang.nfoNotFoundTitle = "Could not find NFO";
