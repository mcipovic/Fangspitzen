﻿
 
 theUILang.erasedataRunNotAvailable	= "Erasedata plugin: rTorrent's user can't access file plugins/erasedata/cleanup.sh for read/execute. Plugin will not work.";

thePlugins.get("erasedata").langLoaded();